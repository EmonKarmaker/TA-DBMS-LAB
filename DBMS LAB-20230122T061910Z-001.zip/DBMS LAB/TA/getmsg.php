<?php
$q = $_POST['q'];
$fac = $_POST['fac'];

$mysqli = new mysqli('localhost', 'root', '', 'ta');

$sql="SELECT content FROM message WHERE studentid = '".$q."' AND teacherid = '".$fac."'";

// Process the query so that we will save the date of birth
$results = $mysqli->query($sql);

// Fetch Associative array
$row = $results->fetch_all(MYSQLI_ASSOC);

// Free result set
$results->free_result();

// Close the connection after using it
$mysqli->close();

echo json_encode($row);
?>