

<?php
error_reporting(E_ERROR | E_PARSE);
session_start();
if(!isset($_SESSION['teacher_id'])){
  header("location: ../index.php"); // ekhane jeno kono prokar error na ashe aar ashleo jeno user sheta na dekhe
  exit;
}
include("db.php");
$id = $_GET['id'];
$section = $_GET['section']; // database add and aager page theke id and section recall

$tid = $_SESSION['teacher_id'];
$sq = "SELECT * FROM `teacher` WHERE id='$tid'";
$result = mysqli_query($conn, $sq); //query execute and save 
$data = $result->fetch_assoc(); // result er data ke fetch and then bhaag kora hoyeche 
if ($result) {
  $_SESSION['teacher_image']=$data['image']; // query true hole image save kore rekheche jeno porobortite easily call korte pari
}

if ($_SERVER["REQUEST_METHOD"] == "POST") { //eta ekta condtion je condition diye value receive kori jeno post meyhod e value ashche kina

  $searchstudent = $_POST["student"];

    $_SESSION['searchstudent'] = $searchstudent;
    
    header("location: searchstudent.php"); //search button er kaaj chilo but kaaj korinai
}


?>


<!DOCTYPE html>
<html lang="en">
  <head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="apple-touch-icon" sizes="76x76" href="uploads/<?=$_SESSION['teacher_image']?>">
<link rel="icon" type="image/png" href="uploads/<?=$_SESSION['teacher_image']?>">

<title>Teacher</title>

<script src="js/jquery.min.js"></script>

<!--     Fonts and icons     -->
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />

<!-- Nucleo Icons -->
<link href="./assets/css/nucleo-icons.css" rel="stylesheet" />
<link href="./assets/css/nucleo-svg.css" rel="stylesheet" />

<!-- Font Awesome Icons -->
<script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>

<!-- Material Icons -->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">

<!-- CSS Files -->



<link id="pagestyle" href="./assets/css/material-dashboard.css?v=3.0.4" rel="stylesheet" />


<style> .modalc { display: none; position: fixed; z-index: 100000; left: 35%; top: 10%; width: 500px; height: 600px; overflow: auto; background-color: white !important; } .modalc-content { background-color: white !important; color: black !important; margin: auto; padding: 20px; border: 1px solid #888; width: 100%; height: 100%; } .closec { color: #aaaaaa; float: right; font-size: 28px; font-weight: bold; } .closec:hover, .closec:focus { color: #000; text-decoration: none; cursor: pointer; } textarea { overflow-y: scroll !important; resize: none; } </style>


  </head>


  <body class="g-sidenav-show  bg-gray-100">
    

    

    
      <aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3   bg-gradient-dark" id="sidenav-main">

  <div class="sidenav-header">
    <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
    <a class="navbar-brand m-0" href="teacherprofile.php" target="_blank">
      <img src="uploads/<?=$_SESSION['teacher_image']?>" class="navbar-brand-img h-100" alt="main_logo">
      <span class="ms-1 font-weight-bold text-white"><?php echo $_SESSION['teacher_name'] ?></span>
    </a>
  </div>


  <hr class="horizontal light mt-0 mb-2">

  <div class="collapse navbar-collapse  w-auto " id="sidenav-collapse-main">
    <ul class="navbar-nav">
       
  
<li class="nav-item">
  <a class="nav-link text-white " href="t_home.php">
    
      <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
        <i class="material-icons opacity-10">dashboard</i>
      </div>
    
    <span class="nav-link-text ms-1">Home</span>
  </a>
</li>

  
<!-- <li class="nav-item">
  <a class="nav-link text-white " href="facultyprojetrequest.php">
    
      <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
        <i class="material-icons opacity-10">table_view</i>
      </div>
    
    <span class="nav-link-text ms-1">Project</span>
  </a>
</li>

<li class="nav-item">
  <a class="nav-link text-white " href="shortcourses.php">
    
      <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
        <i class="material-icons opacity-10">table_view</i>
      </div>
    
    <span class="nav-link-text ms-1"> Short Courses</span>
  </a>
</li> -->

  


  
<li class="nav-item">
  <a class="nav-link text-white " href="teacherlogout.php">
    
      <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
        <i class="material-icons opacity-10">view_in_ar</i>
      </div>
    
    <span class="nav-link-text ms-1">LOGOUT</span>
  </a>
</li>


 
</aside>

      <main class="main-content border-radius-lg ">
        <!-- Navbar -->

<nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" data-scroll="true">
  <div class="container-fluid py-1 px-3">
    <nav aria-label="breadcrumb">
      
      
      
      
    </nav>
    <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
      <div class="ms-md-auto pe-md-3 d-flex align-items-center">

      <form action="" method="POST" class="searchform order-lg-last">
        <div class="form-group d-flex">
          <input type="text" name="student"class="form-control pl-3" placeholder="Search">
          <button type="submit" placeholder="" class="form-control search"><span class="fa fa-search"></span></button>
        </div>
      </form>





     
   
      </div>
      
        <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
          <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
            <div class="sidenav-toggler-inner">
              <i class="sidenav-toggler-line"></i>
              <i class="sidenav-toggler-line"></i>
              <i class="sidenav-toggler-line"></i>
            </div>
          </a>
        </li>
        <li class="nav-item px-3 d-flex align-items-center">
          <a href="javascript:;" class="nav-link text-body p-0">
            <i class="fa fa-cog fixed-plugin-button-nav cursor-pointer"></i>
          </a>
        </li>
        

          
           
              
       
  </div>
</nav>

<!-- End Navbar -->

  <!-- END nav -->
  <br>
  <br>
  <div class='container'>
  <div class='row'>
  <?php
  //echo $id;
  //echo $section;
  $sql = "SELECT * FROM `apply` WHERE cid='$id' AND section='$section' ORDER BY(cgpa) DESC"; //applied 
  $result = mysqli_query($conn, $sql);
  while ($row = mysqli_fetch_array($result)) {  //table eprint korar jono
    $name = $row['sname'];
    $id = $row['sid'];
    $cgpa = $row['cgpa'];
    $nid = $row['id'];
    $cname = $row['cname'];
    $cid = $row['cid'];
    $section=$row['section'];
    $acc = " ";
    $sql1 = "SELECT * FROM `ta` WHERE sid='$id'"; //currently keo TA hishebe ache kina id wise check
    $result1 = mysqli_query($conn, $sql1);
    while ($row1 = mysqli_fetch_array($result1)) {
      $acc = $acc . "," . $row1['cname'] . "(" . $row1['section'] . ")"; //multiple value show

    }

    echo "
    
    
  
    <div class='col-sm'>
     <div>
         <p>Name : $name </p>
         <p>Id : $id</p>
         <p>CGPA : $cgpa </p>
         <p>Current UA : $acc</p>
         <a href='view_profile.php?student_id=".$id."' target='_blank'><button type='button' class='btn btn-primary'>View Profile</button></a>
         <a href='taaddapi.php?name=$name&&id=$id&&cname=$cname&&cid=$cid&&section=$section'><button type='button' class='btn btn-success'>Add</button></a>
         
      </div>
    
    </div>
    
    
    ";

  }
  // iF(!$resultL){

  //   echo "No Apply";
  // }
  
  ?>


<h2 style="text-align:center;">All UA List</h2>
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">Student Name</th>
      <th scope="col">Student Id</th>
      <th scope="col">Course Name</th>
      <th scope="col">Course ID</th>
      <th scope="col">Section</th>
    </tr>
  </thead>

  <?php 
   $sql = "SELECT * FROM `ta`";
    
   $result = mysqli_query($conn, $sql);
  while ($row = mysqli_fetch_array($result)) {
    $id = $row['id']; //shob TA der how korano hoyeche
    

  ?>
  <tbody>
    <tr>
      
      <td><?php echo $row['sname'] ?></td>
      <td><?php echo $row['sid'] ?></td>
      <td><?php echo $row['cname'] ?></td>
      <td><?php echo $row['cid'] ?></td>
      <td><?php echo $row['section'] ?></td>
      <td><button id="myBtn_<?php echo $row['sid'] ?>" class="btn btn-primary">Message</button></td>
      <td><?php echo" <a href='deleteua.php?id=$id'><button type='button' class='btn btn-primary'>Delete</button></a> ";?></td>
    </tr>
   

  </tbody>
  <div id="myModal_<?php echo $row['sid'] ?>" class="modal_<?php echo $row['sid'] ?>" style="background-color: white; color: black;">
    <div class="modal_<?php echo $row['sid'] ?>-content" style="background-color: white; color: black;">
      <span class="close_<?php echo $row['sid'] ?>">&times;</span>
      <div id="messagechat_<?php echo $row['sid'] ?>" style="width: 100%; height: 350px; border: 1px solid grey;"></div><br>
      <input id="typemsg_<?php echo $row['sid'] ?>" type="text" value="" style="width: 100%; border: 1px solid grey;" placeholder="Type something"><br><br>
      <button type='button' class='btn btn-success' onClick="getMsg('<?php echo $row['sid'] ?>')">Load Previous</button>
      <button type='button' class='btn btn-success' onClick="sendMsg('<?php echo $row['sid'] ?>')">Send</button><br>
      <span id="succ_<?php echo $row['sid'] ?>" style="color: green;"></span>
    </div>
  </div>
  <script>var modal_<?php echo $row['sid'] ?> = document.getElementById("myModal_<?php echo $row['sid'] ?>"); var btn_<?php echo $row['sid'] ?> = document.getElementById("myBtn_<?php echo $row['sid'] ?>"); var span_<?php echo $row['sid'] ?> = document.getElementsByClassName("close_<?php echo $row['sid'] ?>")[0]; btn_<?php echo $row['sid'] ?>.onclick = function() { modal_<?php echo $row['sid'] ?>.style.display = "block"; }; span_<?php echo $row['sid'] ?>.onclick = function() { modal_<?php echo $row['sid'] ?>.style.display = "none"; }; window.onclick = function(event) { if (event.target == modal_<?php echo $row['sid'] ?>) { modal_<?php echo $row['sid'] ?>.style.display = "none"; } }</script>
  <style> .modal_<?php echo $row['sid'] ?> { display: none; position: fixed; z-index: 100000; left: 35%; top: 10%; width: 500px; height: 600px; overflow: auto; background-color: white !important; } .modal_<?php echo $row['sid'] ?>-content { background-color: white !important; color: black !important; margin: auto; padding: 20px; border: 1px solid #888; width: 100%; height: 100%; } .close_<?php echo $row['sid'] ?> { color: #aaaaaa; float: right; font-size: 28px; font-weight: bold; } .close_<?php echo $row['sid'] ?>:hover, .close_<?php echo $row['sid'] ?>:focus { color: #000; text-decoration: none; cursor: pointer; } textarea { overflow-y: scroll !important; resize: none; } </style>
 <?php } ?>
</table>
    
  </div>
  </div>
    
   



  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  
  <footer class="footer py-4  ">
  <div class="container-fluid">
    <div class="row align-items-center justify-content-lg-between">
      <div class="col-lg-6 mb-lg-0 mb-4">
        <div class="copyright text-center text-sm text-muted text-lg-start">
          <h4>© 2022
          made  by
          <a href="" class="font-weight-bold" target="_blank">Team big_O</a></h4>
          
        </div>
      </div>
     
    </div>
  </div>
</footer>

            </div>

         
       </main>
    

      
          <div class="fixed-plugin">
    <a class="fixed-plugin-button text-dark position-fixed px-3 py-2">
      <i class="material-icons py-2">settings</i>
    </a>
    <div class="card shadow-lg">
      <div class="card-header pb-0 pt-3">
        <div class="float-start">
          <h5 class="mt-3 mb-0">UIU Activity Tracker</h5>
          
        </div>
        <div class="float-end mt-4">
          <button class="btn btn-link text-dark p-0 fixed-plugin-close-button">
            <i class="material-icons">clear</i>
          </button>
        </div>
        <!-- End Toggle Button -->
      </div>
      <hr class="horizontal dark my-1">
      <div class="card-body pt-sm-3 pt-0">
        <!-- Sidebar Backgrounds -->
        

        <!-- Sidenav Type -->
        
        <div class="mt-3">
          <h6 class="mb-0">Sidenav Type</h6>
          
        </div>

        <div class="d-flex">
          <button class="btn bg-gradient-dark px-3 mb-2 active" data-class="bg-gradient-dark" onclick="sidebarType(this)">Dark</button>
          <button class="btn bg-gradient-dark px-3 mb-2 ms-2" data-class="bg-transparent" onclick="sidebarType(this)">Transparent</button>
          <button class="btn bg-gradient-dark px-3 mb-2 ms-2" data-class="bg-white" onclick="sidebarType(this)">White</button>
        </div>

        <p class="text-sm d-xl-none d-block mt-2">You can change the sidenav type just on desktop view.</p>
        

        <!-- Navbar Fixed -->
        
        <div class="mt-3 d-flex">
          <h6 class="mb-0">Navbar Fixed</h6>
          <div class="form-check form-switch ps-0 ms-auto my-auto">
            <input class="form-check-input mt-1 ms-auto" type="checkbox" id="navbarFixed" onclick="navbarFixed(this)">
          </div>
        </div>
        

        
        <hr class="horizontal dark my-3">
        <div class="mt-2 d-flex">
          <h6 class="mb-0">Light / Dark</h6>
          <div class="form-check form-switch ps-0 ms-auto my-auto">
            <input class="form-check-input mt-1 ms-auto" type="checkbox" id="dark-version" onclick="darkMode(this)">
          </div>
        </div>
        <hr class="horizontal dark my-sm-4">
        
     
          
        </div>
      </div>
    </div>
</div>


<!--   Core JS Files   -->
<script src="./assets/js/core/popper.min.js" ></script>
<script src="./assets/js/core/bootstrap.min.js" ></script>
<script src="./assets/js/plugins/perfect-scrollbar.min.js" ></script>
<script src="./assets/js/plugins/smooth-scrollbar.min.js" ></script>





<script>
  var win = navigator.platform.indexOf('Win') > -1;
  if (win && document.querySelector('#sidenav-scrollbar')) {
    var options = {
      damping: '0.5'
    }
    Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
  }
</script>

<script>
function getMsg(idstr) {
  document.getElementById("succ_"+idstr).innerHTML = "";
  var formData = {
    'q': idstr,
    'fac':'<?php echo $_SESSION["teacher_id"]; ?>'
  };
  $.ajax({
      type: 'POST', //we are using POST method to submit the data to the server side
      url: 'http://localhost/TA/getmsg.php', // get the route value
      data: formData, // our serialized array data for server side
      success: function (response) {//once the request successfully process to the server side it will return result here
        document.getElementById("messagechat_"+idstr).innerHTML = "";
        response = JSON.parse(response);
        $.each(response, function(key,value) {
          document.getElementById("messagechat_"+idstr).innerHTML += value.content+'<br>';
          //$("messagechat_"+idstr).append(value.content+'<br>');
        });
      }
  });
}

function sendMsg(idstr) {
  var msgcontent = document.getElementById("typemsg_"+idstr).value;
  var formData = {
    'q': idstr,
    'fac': '<?php echo $_SESSION["teacher_id"]; ?>',
    'msgcontent': msgcontent
  };
  $.ajax({
      type: 'POST', //we are using POST method to submit the data to the server side
      url: 'http://localhost/TA/send.php', // get the route value
      data: formData, // our serialized array data for server side
      success: function (response) {//once the request successfully process to the server side it will return result here
        document.getElementById("succ_"+idstr).innerHTML = response;
      }
  });
}
</script>

<!-- Github buttons -->
<script async defer src="https://buttons.github.io/buttons.js"></script>


<!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc --><script src="./assets/js/material-dashboard.min.js?v=3.0.4"></script>
  </body>

</html>











































































































