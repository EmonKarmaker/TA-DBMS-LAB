<?php
$q = $_POST['q'];
$fac = $_POST['fac'];
$msgcontent = $_POST['msgcontent'];

$mysqli = new mysqli('localhost', 'root', '', 'ta');

$sql="INSERT INTO message (content, studentid, teacherid) VALUES ('<b>$fac</b>: $msgcontent', '$q', '$fac');";

// Process the query so that we will save the date of birth
$mysqli->query($sql);

// Close the connection after using it
$mysqli->close();

$succ = "Message sent successfully. Please reload.";

echo json_encode($succ);
?>