-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 01, 2023 at 07:29 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ta`
--

-- --------------------------------------------------------

--
-- Table structure for table `apply`
--

CREATE TABLE `apply` (
  `id` int(11) NOT NULL,
  `sname` varchar(250) NOT NULL,
  `sid` varchar(250) NOT NULL,
  `cgpa` varchar(250) NOT NULL,
  `cname` varchar(250) NOT NULL,
  `cid` varchar(250) NOT NULL,
  `section` varchar(250) NOT NULL,
  `tname` varchar(250) NOT NULL,
  `ctimestart` varchar(250) NOT NULL,
  `ctimeend` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `apply`
--

INSERT INTO `apply` (`id`, `sname`, `sid`, `cgpa`, `cname`, `cid`, `section`, `tname`, `ctimestart`, `ctimeend`) VALUES
(37, 'Emon Karmoker', '011201386', '3.80', 'Structured Programming Language', ' CSE 1111', 'A', 'Mr. Farhan Anan Himu', '08:30', '10:00'),
(38, 'Saif ', '011201223', '3.95', 'Structured Programming Language', ' CSE 1111', 'A', 'Mr. Farhan Anan Himu', '08:30', '10:00'),
(39, 'Nazmul Hoda', '011201224', '3.70', 'Database Management Systems Laboratory', 'CSE 3522', 'C', 'Md. Mohaiminul Islam', '11:00', '13:30'),
(40, 'Nazmul Hoda', '011201224', '4.00', 'Structured Programming Language', ' CSE 1111', 'B', ' Anika Tasnim Rodela', '10:00', '11:30');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `cid` varchar(200) NOT NULL,
  `cname` varchar(1000) NOT NULL,
  `section` varchar(200) NOT NULL,
  `tname` varchar(200) NOT NULL,
  `tid` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `Room` varchar(100) NOT NULL,
  `ctimestart` varchar(100) NOT NULL,
  `ctimeend` varchar(100) NOT NULL,
  `Occupied` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `cid`, `cname`, `section`, `tname`, `tid`, `department`, `Room`, `ctimestart`, `ctimeend`, `Occupied`) VALUES
(16, ' CSE 1111', 'Structured Programming Language', 'A', 'Mr. Farhan Anan Himu', 'FAH', 'CSE', '401', '08:30', '10:00', 35),
(17, ' CSE 1111', 'Structured Programming Language', 'B', ' Anika Tasnim Rodela', 'ATR', 'CSE', '402', '10:00', '11:30', 35),
(19, ' CSE 1111', 'Structured Programming Language', 'C', 'Mr. Md. Benzir Ahamed', 'BA', 'CSE', '406', '15:00', '16:30', 35),
(20, 'CSE 1115 ', 'Object-Oriented Programming', 'A', 'Dr. Dewan Md. Farid', 'DF', 'CSE', '401', '10:00', '12:30', 0),
(21, 'CSE 1115 ', 'Object-Oriented Programming', 'B', 'Mr. Farhan Anan Himu', 'FAH', 'CSE', '403', '12:00', '13:30', 0),
(22, 'CSE 1115 ', 'Object-Oriented Programming', 'C', 'Md. Rayhan Ahmed', 'RA', 'CSE', '405', '14:00', '15:30', 0),
(23, 'CSE 2215', 'Data Structure and Algorithms I', 'A', 'MD. TAREK HASAN', 'TH', 'CSE', '421', '09:00', '10:30', 0),
(24, 'CSE 2215', 'Data Structure and Algorithms I', 'B', 'Md. Mohaiminul Islam', 'MOI', 'CSE', '406', '13:00', '14:30', 0),
(25, 'CSE 2215', 'Data Structure and Algorithms I', 'C', 'Dr.Mohammad Nurul Huda', 'MNH', 'CSE', '329', '10:30', '12:00', 0),
(26, 'CSE 2213 ', 'Discrete Mathematics', 'A', 'Minhajul Bashir', 'MB', 'CSE', '402', '08:00', '09:30', 0),
(27, 'CSE 2213 ', 'Discrete Mathematics', 'B', 'Mr. Md. Mumtahin Habib Ullah Mazumder', 'MHU', 'CSE', '401', '13:00', '14:30', 0),
(28, 'CSE 2213 ', 'Discrete Mathematics', 'E', 'Md. Rayhan Ahmed', 'RA', 'CSE', '406', '09:00', '10:30', 0),
(30, 'CSE 3521', 'Database Management Systems', 'E', 'Sadia Islam', 'SAI', 'CSE', '402', '15:00', '16:30', 0),
(31, 'CSE 3521', 'Database Management Systems', 'B', 'Mr. Farhan Anan Himu', 'FAH', 'CSE', '401', '10:00', '11:30', 0),
(32, 'CSE 3521', 'Database Management Systems', 'A', 'Sadia Islam', 'SAI', 'CSE', '404', '08:00', '09:30', 0),
(33, 'CSE 2217', 'Data Structure and Algorithms II', 'A', 'MD. TAREK HASAN', 'TH', 'CSE', '424', '10:30', '12:00', 0),
(34, 'CSE 2217', 'Data Structure and Algorithms II', 'D', 'Fariha Tabassum Islam', 'FTI', 'CSE', '433', '14:00', '15:30', 0),
(35, 'CSE 2217', 'Data Structure and Algorithms II', 'E', 'Gourab Saha', 'GS', 'CSE', '405', '10:00', '11:30', 0),
(36, 'CSE 3522', 'Database Management Systems Laboratory', 'C', 'Md. Mohaiminul Islam', 'MOI', 'CSE', '425', '11:00', '13:30', 36),
(37, 'CSE 123', 'Electronics', 'A', 'Mr. Md. Abir Hassan', 'AH', 'CSE', '404', '10:00', '12:30', 0),
(38, 'CSE 123', 'Electronics', 'B', 'Mr. Anik Mazumder', 'AM', 'CSE', '403', '08:30', '10:00', 0),
(39, 'CSE 123', 'Electronics', 'C', 'Mr. Md. Abir Hassan', 'AH', 'CSE', '405', '08:30', '10:00', 0),
(40, 'CSE 3313 ', 'Computer Architecture', 'A', 'Mr. Shoib Ahmed Shourav', 'SAS', 'CSE', '429', '10:30', '12:00', 0),
(41, 'CSE 3313 ', 'Computer Architecture', 'B', 'Mr. Anik Mazumder', 'AM', 'CSE', '404', '12:00', '14:30', 0),
(42, 'CSE 3313 ', 'Computer Architecture', 'D', 'Mr. Shoib Ahmed Shourav', 'SAS', 'CSE', '402', '12:00', '13:30', 0),
(43, 'CSE 2233', 'Theory of Computation', 'A', 'Mr. Akib Zaman', 'AZ', 'CSE', '429', '08:30', '10:00', 0),
(44, 'CSE 2233', 'Theory of Computation', 'C', ' Anika Tasnim Rodela', 'ATR', 'CSE', '404', '14:00', '15:30', 0),
(45, 'CSE 2233', 'Computer Architecture', 'B', 'Ms. Farhanaz Farheen', 'FF', 'CSE', '403', '10:30', '12:00', 0),
(46, 'CSE 3522', 'Database Management Systems Laboratory', 'A', 'Dr. Salekul Islam', 'SI', 'CSE', '525', '08:30', '11:00', 36),
(47, 'CSE 3522', 'Database Management Systems Laboratory', 'B', 'Sadia Islam', 'SAI', 'CSE', '530', '11:00', '13:30', 36),
(48, 'CSE 1325', 'Digital Logic Design', 'A', 'Minhajul Bashir', 'MB', 'CSE', '406', '11:00', '12:30', 0),
(49, 'CSE 1325', 'Digital Logic Design', 'B', 'Mr. Shoib Ahmed Shourav', 'SAS', 'CSE', '407', '08:30', '10:00', 0),
(50, 'CSE 1325 ', 'Digital Logic Design', 'C', 'Fariha Tabassum Islam', 'FTI', 'CSE', '407', '11:00', '12:30', 0),
(51, 'CSE 4325 ', 'Microprocessors and Microcontrollers ', 'A', 'Mr. Md. Mahbub Hossain Raton', 'MHR', 'CSE', '425', '08:30', '10:00', 0),
(52, 'CSE 4325 ', 'Microprocessors and Microcontrollers ', 'C', 'Mr. Md. Mahbub Hossain Raton', 'MHR', 'CSE', '408', '11:30', '13:00', 0),
(53, 'CSE 4325 ', 'Microprocessors and Microcontrollers ', 'D', 'Fahim Hafiz', 'FH', 'CSE', '408', '08:30', '10:00', 0),
(55, 'CSE 3411 ', 'System Analysis and Design', 'A', 'Mr. Suman Ahmmed', 'SM', 'CSE', '407', '13:00', '14:30', 0),
(56, 'CSE 3411 ', 'System Analysis and Design', 'B', 'Adiba Shaira', 'AS', 'CSE', '409', '08:30', '10:00', 0),
(57, 'CSE 3421 ', 'Software Engineering', 'A', 'MD. TAREK HASAN', 'TH', 'CSE', '413', '01:30', '03:00', 0),
(58, 'CSE 3421 ', 'Software Engineering', 'B', 'Md. Rafi-Ur-Rashid', 'RUR', 'CSE', '409', '10:30', '12:00', 0),
(59, 'CSE 3811 ', 'Artificial Intelligence', 'A', 'Fariha Tabassum Islam', 'FTI', 'CSE', '411', '08:30', '10:00', 0),
(60, 'CSE 3811 ', 'Artificial Intelligence', 'B', 'Ms. Rubaiya Rahtin Khan', 'RRK', 'CSE', '409', '13:00', '14:30', 0),
(61, 'BIO 3105 ', 'Biology for Engineers', 'A', 'Ms.Nipa Roy', 'NR', 'CSE', '408', '13:30', '15:00', 0),
(62, 'BIO 3105 ', 'Biology for Engineers', 'B', 'Hasin Anupama Azhari', 'HAA', 'CSE', '410', '10:30', '12:00', 0),
(63, 'IPE 3401 ', 'Industrial and Operational Management', 'B', 'Gourab Kumar Roy', 'GKR', 'CSE', '429', '13:00', '14:30', 0),
(64, 'CSE 2118', 'Advanced Object Oriented Programming Laboratory', 'C', 'Ajwad Akil', 'AA', 'CSE', '529', '08:30', '11:00', 37),
(65, ' CSE 4165 ', 'Web Programming', 'F', 'Nahid Hossain', 'NH', 'CSE', '410', '13:00', '14:30', 0),
(66, 'CSE 4181 ', 'Mobile Application Development', 'B', 'Sufi Aurangzeb Hossain', 'SAH', 'CSE', '411', '10:30', '12:00', 0),
(67, 'MATH 2205 ', 'Probability and Statistics ', 'A', 'Jashodhan Saha', 'JS', 'CSE', '405', '12:00', '13:30', 0),
(68, 'CSE 3711 ', 'Computer Networks', 'A', 'Dr. Md. Abul Kashem Mia', 'AKM', 'CSE', '412', '10:30', '12:00', 0),
(69, 'CSE 3715 ', 'Data Communication', 'A', 'Moynuddin Ahmed Shibly', 'MAS', 'CSE', '411', '14:30', '16:00', 0),
(70, 'CSE 4889 ', 'Machine Learning', 'A', 'Dr. Dewan Md. Farid', 'DF', 'CSE', '412', '08:30', '10:00', 0),
(72, 'CSE 4521 ', 'Computer Graphics', 'A', 'Md. Hasan Al Kayem', 'HAK', 'CSE', '412', '13:30', '15:00', 0),
(73, 'CSE 4587 ', 'Cloud Computing', 'B', 'Dr. A.K.M. Muzahidul Islam', 'A.K.M', 'CSE', '413', '08:30', '10:00', 0),
(74, 'PHY 2105 ', 'Physics', 'B', 'Prof. Dr. Md. Abu Saklayen', 'ABS', 'CSE', '412', '10:30', '12:00', 0),
(75, 'EEE 1001', 'Electrical Circuits I ', 'A', 'Mr. B.K.M. Mizanur Rahman', 'BKM', 'EEE', '601', '08:30', '10:00', 0),
(76, 'EEE 1001', 'Electrical Circuits I ', 'C', 'Dr. M. Rezwan Khan', 'RK', 'EEE', '602', '10:30', '12:00', 0),
(77, ' EEE 1003', 'Electrical Circuits II', 'A', 'Dr. M. Rezwan Khan', 'RK', 'EEE', '601', '13:30', '15:00', 0),
(78, 'EEE 2101', 'Electronics I', 'A', 'Sandid Muneer', 'SnM', 'EEE', '601', '10:00', '11:30', 0),
(79, ' CHE 2101', 'Chemistry', 'A', 'Mr. Mohammad Mahboob Ali Siddiqi', 'MASQ', 'EEE', '601', '11:30', '13:00', 0),
(80, ' EEE 2401', 'Structured Programming Language', 'B', 'Mr. Salahuddin Ahmed', 'SAMD', 'EEE', '602', '08:30', '10:00', 0),
(81, ' EEE 2103', 'Electronics II', 'C', 'Mr. Md. Zubair Alam', 'ZA', 'EEE', '603', '10:30', '12:00', 0),
(82, ' EEE 2200', 'Electrical Wiring and Drafting', 'A', 'Mr. Md. Zubair Alam', 'ZA', 'EEE', '602', '13:00', '15:30', 0),
(83, ' EEE 2200', 'Electrical Wiring and Drafting', 'B', 'Mr. Avijit Saha', 'AVS', 'EEE', '602', '15:00', '16:30', 0),
(84, 'EEE 2201', 'Energy Conversion I ', 'A', 'Mr. B.K.M. Mizanur Rahman', 'BKM', 'EEE', '604', '10:30', '12:00', 0),
(85, 'EEE 2301', 'Signals and Linear Systems', 'A', 'Dr. Raqibul Mostafa', 'RM', 'EEE', '603', '08:30', '10:00', 0),
(86, 'EE 2203', 'Energy Conversion II', 'A', 'Dr. Intekhab Alam', 'IA', 'EEE', '603', '13:30', '15:00', 0),
(87, 'EEE 3107', 'Electrical Properties of Materials', 'A', 'Dr. Md. Iqbal Bahar Chowdhury', 'IBC', 'EEE', '604', '08:30', '10:00', 0),
(88, 'SOC 3101', 'Society, Environment and Engineering Ethics', 'A', 'Md. Mizanur Rahman', 'MR', 'EEE', '604', '13:30', '15:00', 0),
(89, 'EEE 3309', 'Digital Signal Processing', 'A', 'Dr. Raqibul Mostafa', 'RM', 'EEE', '605', '10:30', '12:00', 0),
(90, 'EEE 3205', 'Power System', 'A', 'Mr. B.K.M. Mizanur Rahman', 'BKM', 'EEE', '605', '15:00', '16:30', 0),
(91, 'IPE 4101', 'Industrial Production Engineering ', 'A', 'Gourab Kumar Roy', 'GR', 'EEE', '604', '15:00', '16:30', 0),
(93, ' EEE 2105 ', 'Digital Electronics', 'A', 'Mr. Md. Zubair Alam', 'ZA', 'EEE', '605', '08:30', '10:00', 0),
(94, 'EEE 3207 ', 'Power Electronics', 'A', 'Dr. Intekhab Alam', 'IA', 'EEE', '605', '12:30', '14:00', 0),
(95, 'EEE 3303', 'Probability, Statistics and Random Variables', 'A', 'Dr. Khawza Iftekhar Uddin Ahmed', 'KIUA', 'EEE', '606', '08:30', '10:00', 0),
(96, ' EEE 3403', 'Microprocessor and Interfacing', 'A', 'Mr. Salahuddin Ahmed', 'SAMD', 'EEE', '606', '10:30', '12:00', 0),
(97, 'EEE 3305', 'Engineering Electromagnetics', 'A', 'Mr. B.K.M. Mizanur Rahman', 'BKM', 'EEE', '606', '12:30', '14:00', 0),
(99, 'ECN 2214 ', 'Macroeconomics', 'A', 'Ms. Tanzila Amir', 'TA', 'BBA', '301', '08:30', '10:00', 0),
(101, 'BST 1308 ', 'Business Statistics I', 'B', 'Ms. Mimnun Sultana', 'MS', 'BBA', '302', '08:30', '10:00', 0),
(102, 'BST 2216', 'Business Statistics II', 'A', 'Md. Kazimul Hoque', 'KH', 'BBA', '301', '10:30', '12:00', 0),
(103, 'ACN 1205 ', 'Financial Accounting I', 'A', 'Mr. Mofijul Hoq Masum', 'MHM', 'BBA', '301', '12:30', '14:00', 0),
(104, 'ACN 2215 ', 'Management Accounting', 'B', 'Dr. Mohammad A. Ashraf', 'MAA', 'BBA', '301', '15:00', '16:30', 0),
(105, 'MGT 1307 ', 'Principles of Management', 'A', 'Mr. Mohammad Behroz Jalil', 'BJ', 'BBA', '302', '10:30', '12:00', 0),
(106, 'MGT 2318', 'Organizational Behavior', 'D', 'Mr. Mohammad Behroz Jalil', 'BJ', 'BBA', '302', '12:30', '14:00', 0),
(108, 'MGT 4356', 'Strategic Management', 'C', 'Prof. Dr. Abu Saleh Md. Sohel-Uz-Zaman', 'ASSZ', 'BBA', '303', '08:30', '10:00', 0),
(109, 'FIN 2319 ', 'Principles of Finance', 'B', 'Md. Qamruzzaman', 'MQ', 'BBA', '302', '15:00', '16:30', 0),
(110, 'CST 1206', 'Computer Applications', 'A', 'Jerin Haque Chhanda', 'JHC', 'BBA', '303', '10:30', '12:00', 0),
(111, 'IBS 3338', 'Export Import Management', 'B', 'Dr. Seyama Sultana', 'SeyS', 'BBA', '303', '12:30', '14:00', 0),
(112, 'ACN 4135 ', 'Taxation', 'C', 'Mr. Mofijul Hoq Masum', 'MHM', 'BBA', '303', '15:00', '16:30', 0),
(113, 'MKT 4309', 'Global Marketing', 'A', 'Dr. Seyama Sultana', 'SeyS', 'BBA', '304', '08:30', '10:00', 0),
(114, 'MKT 4308', 'Supply Chain Management', 'B', 'Mr. Abu Zafar Md. Rashed Osman', 'ARO', 'BBA', '304', '10:30', '12:00', 0),
(115, 'HRM 4365 ', 'Change Management', 'A', 'Ms. Ishrat Sultana', 'IS', 'BBA', '304', '12:30', '14:00', 0),
(116, 'CSE ', 'Object Oriented Programming', 'A', '', '3556u7', 'CSE', '423', '13:12', '13:13', 0),
(117, 'CSE 3712', 'Computer Networks Laboratory', 'A', 'Gourab Saha', 'GOS', 'CSE', '519', '8:30', '11:00', 39),
(118, 'CSE 3712', 'Computer Networks Laboratory', 'B', 'Gourab Saha', 'GOS', 'CSE', '520', '11:00', '1:30', 39),
(119, 'CSE 3712', 'Computer Networks Laboratory', 'C', 'Gourab Saha', 'GOS', 'CSE', '521', '2:00', '4:30', 39),
(120, 'CSE 4510', 'Operating Systems Laboratory', 'A', 'Santi Brata Nath Joy', 'SBNJoy', 'CSE', '408', '2:00', '4:30', 38),
(121, 'CSE 4510', 'Operating Systems Laboratory', 'B', 'Santi Brata Nath Joy', 'SBNJoy', 'CSE', '421', '8:30', '11:00', 38);

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(10) NOT NULL,
  `content` varchar(500) NOT NULL,
  `studentid` varchar(15) NOT NULL,
  `teacherid` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `content`, `studentid`, `teacherid`) VALUES
(8, 'SAI: Hi ', '011201223', 'SAI'),
(9, 'SAI: Do you want to be a TA?', '011201223', 'SAI'),
(10, '<b>SAI</b>: Do you want to be a TA?', '011201223', 'SAI'),
(11, '<b>SAI</b>: vcfbnvb', '011201223', 'SAI'),
(12, '<b>SAI</b>: hjdsjsgdhj', '011201223', 'SAI'),
(13, '<b>SAI</b>: Hi', '011201223', 'SAI'),
(14, '<b>SAI</b>: Hid', '011201223', 'SAI');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `sname` varchar(250) NOT NULL,
  `sid` varchar(250) NOT NULL,
  `cid` varchar(1000) NOT NULL,
  `cname` varchar(500) NOT NULL,
  `gpa` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`sname`, `sid`, `cid`, `cname`, `gpa`) VALUES
('Nazmul Hoda', '011201224', 'CSE 1111', 'Structured Programming Language', '4.00'),
('Santi Brata Nath Joy', '011201230', 'CSE 1111', 'Structured Programming Language', '4.00'),
('Abdullah Al Sakib', '011201240', 'CSE 1115', 'Object-Oriented Programming\r\n', '4.00'),
('Mahadi Hasan', '011201205', 'CSE 4510', 'Operating Systems Laboratory', '4.00'),
('Saikat ', '011201214', 'CSE 3712', 'Computer Networks Laboratory', '4.00'),
('Saif ', '011201223', 'CSE 3522', 'Database Management Systems Laboratory', '4.00'),
('Mirza hasan', '011201247', 'CSE 3712', 'Computer Networks Laboratory', '4.00'),
('Arshadul Mokaddis', '011201260', 'CSE 4510', 'Operating Systems Laboratory', '4.00'),
('Fahad Rahman', '011203014', 'CSE 2118', 'Advanced Object Oriented Programming Laboratory', '4.00'),
('Abrar Zahin', '011221018', 'CSE 3522', 'Database Management Systems Laboratory', '4.00');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `name` varchar(100) NOT NULL,
  `dob` varchar(60) NOT NULL,
  `gender` varchar(60) NOT NULL,
  `id` varchar(15) NOT NULL,
  `email` varchar(255) NOT NULL,
  `number` varchar(50) NOT NULL,
  `department` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `image` varchar(500) NOT NULL,
  `cgpa` varchar(10) NOT NULL,
  `github` varchar(200) NOT NULL,
  `website` varchar(200) NOT NULL,
  `linkedin` varchar(200) NOT NULL,
  `address` varchar(255) NOT NULL,
  `intro` varchar(300) NOT NULL,
  `about` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`name`, `dob`, `gender`, `id`, `email`, `number`, `department`, `password`, `image`, `cgpa`, `github`, `website`, `linkedin`, `address`, `intro`, `about`) VALUES
('Tasmin Sanjida ', '1997-01-31T12:59', 'Female', '011182044', 'tasmin182@gmail.com', '01700000004', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-632335f1f15ec8.26678925.jpg', '3.80', '', '', '', '', '', ''),
('Md. Enamul Haque', '1998-02-01T18:59', 'Male', '011182055 ', 'enamul182@gmail.com', '01700000005', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63233649dce4f9.92085245.jpg', '3.85', '', '', '', '', '', ''),
('Shifa Chowdhury Iwase', '1998-06-07T20:22', 'Female', '011183003', 'shafia183@gmail.com', '01700000006', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63233704d71136.74838371.jpg', '3.90', '', '', '', '', '', ''),
('A.S.M Redowan', '1998-02-01T00:27', 'Male', '011191004', 'redowan191@gmail.com', '01700000007', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-632337cf7dd3f7.24734031.jpg', '3.29', '', '', '', '', '', ''),
('Md. Naimul Karim Hredoy', '1998-05-06T23:38', 'Male', '011191080', 'naimul191@gmail.com', '01700000008', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-632338a73f7776.25159104.jpg', '3.80', '', '', '', '', '', ''),
('Akib Rayhan', '1998-12-30T10:41', 'Male', '011191154', 'a.rayhan191@gmail.com', '01700000010', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-6323390cc069f3.71666960.jpg', '3.50', '', '', '', '', '', ''),
('Md.Eram Bin Tanbir', '1998-11-25T06:40', 'Male', '011191182', 'eram191@gmail.com', '01700000011', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Md Ferdous Hasan', '1998-12-09T06:30', 'Male', '011191225', 'ferdous191@gmail.com', '01700000012', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
(' Mohaimenul Azam Khan Raiaan', '1998-03-01T16:50', 'Male', '011191228', 'azam191@gmail.com', '01700000013', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Jubayer Hossen', '1998-11-30T15:50', 'Male', '011191254', 'jubayer191@gmail.com', '01700000015', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Md. Jobayer Rahman', '1998-05-02T16:40', 'Male', '011192070', 'jobayerr192@gmail.com', '01700000016', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Swapnil Biswas ', '1997-05-22T12:40', 'Female', '011192072 ', 'swapnil192@gmail.com', '01700000017', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Md. Shakil Ahmed', '1997-06-11T19:45', 'Male', '011192077', 'shakil192@gmail.com', '01800000000', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Arindam Kundu Amit ', '1997-03-06T09:50', 'Male', '011192107', 'kundu192@gmail.com', '01800000001', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Proma Hossain Progga', '1998-08-11T20:40', 'Female', '011192126 ', 'proma192@gmail.com', '01800000003', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Ahmed Shabab Noor', '1998-08-12T20:48', 'Male', '011193024', 'shabab193@gmail.com', '01800000004', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Hasibul Hasan Rupok', '1997-09-10T16:40', 'Male', '011201002', 'hasan201@gmail.com', '01800000005', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Shabrina Airen Esha', '1999-06-12T16:40', 'Female', '011201005', 'airen201@gmail.com', '01800000007', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Shahil Yasar Haque ', '1998-05-22T20:30', 'Male', '011201021', 'shahil201@gmail.com', '01800000017', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Abu Sayem Md. Siam ', '1997-05-10T19:50', 'Male', '011201033 ', 'sayem201@gmail.com', '01800000018', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Yeasir Arafat', '1997-02-22T08:40', 'Male', '011201035', 'yeasir201@gmail.com', '01800000019', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Mithun Halder ', '1999-11-26T14:30', 'Male', '011201041', 'halder201@gmail.com', '01800000020', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Debopom Sutradhar', '1999-08-12T08:10', 'Male', '011201046', 'debopom201@gmail.com', '01600000000', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Nurzihan Fatema Reya', '1998-08-22T19:34', 'Female', '011201085', 'reya201@gmail.com', '01600000001', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Suraia Afroz Maria', '1999-07-12T10:30', 'Female', '011201089', 'afroz201@gmail.com', '01600000002', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Mahadi Hasan', '2022-12-16T10:40', 'Male', '011201205', 'mhasan@gmail.com', '0177025896', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Saikat ', '2022-12-14T10:34', 'Male', '011201214', 'shossain@gmail.com', '0177000000000', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Saif ', '2000-02-28T13:06', 'Male', '011201223', 'saif@gmail.com', '0170000001', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-6326d9bef08cc2.72843972.jpg', '3.95', '', '', '', '', '', ''),
('Nazmul Hoda', '51996-02-22T22:00', 'Male', '011201224', 'nhoda201224@gmail.com', '01700005621', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63aac6651fc457.25083162.jpg', '4.00', '', '', 'https://bd.linkedin.com/in/jawwadfida', '', '', ''),
('Nazu', '2022-12-17T22:18', 'Male', '011201229', 'nhodatuhin@gmail.com', '017700000000', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Santi Brata Nath Joy', '1996-10-05T14:52', 'Male', '011201230', 'sjoy@gmail.com', '01700000001', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', 'joy.jpg', '4.00', '', '', '', '', '', ''),
('Abdullah Al Sakib', '2000-03-20', 'Male', '011201240', 'asakib201240@bscse.uiu.ac.bd', '01775332747', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63582d288ddec7.29145910.jpg', '3.76', 'https://github.com/abdullah201240', 'https://abdullah201240.github.io/personal_website/', 'https://www.linkedin.com/in/abdullah-al-sakib-8b35461a6/', 'Dhaka', 'Software Developer', ' Software developer with excellent problem-solving skills and ability to perform well in a team. Passionate about coding and making projects'),
('Mirza hasan', '2022-07-13T13:02', 'Male', '011201247', 'mhasan201247@bscse.uiu.ac.bd', '01623398837', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63230ed9548ee8.86393021.jpg', '3.51', '', '', '', '', '', ''),
('Arshadul Mokaddis', '1999-11-30T05:00', 'Male', '011201260', 'mokaddis201@gmail.com', '01785389594', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-632330ea251ff2.88948293.jpg', '3.63', '', '', '', '', '', ''),
('Emon Karmoker', '1997-08-09T05:20', 'Male', '011201386', 'emon@gmail.com', '01700000002', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', 'emon.jpg', '3.80', '', '', '', '', '', ''),
('Fahad Rahman', '1999-05-12T03:35', 'Male', '011203014', 'fahad203@gmail.com', '01600000003', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-632717849294e9.23712725.jpg', '', '', '', '', '', '', ''),
('Abrar Zahin', '2022-12-08T20:01', 'Male', '011221018', 'ab@gmail.com', '01947121908', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Tuhin', '2022-12-17T21:37', 'Male', '011223224', 'tuhin@gmail.com', '01111111122', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63a9beec0bae40.34922831.jpg', '3.55', '', '', '', '', '', ''),
('Binta Mohammed Adib Zeta', '1996-07-20T09:40', 'Female', '021173013', 'binta173@gmail.com', '01600000004', 'EEE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-632339993f02b9.66407231.jpg', '3.50', '', '', '', '', '', ''),
('Md. Tanjilul Haque', '1996-07-22T20:30', 'Male', '021181005', 'tanjiul181@gmail.com', '01600000005', 'EEE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63233a17aa64d0.27179200.jpg', '3.60', '', '', '', '', '', ''),
('Jannatul Ferdous Shamma', '1996-02-17T16:50', 'Female', '021181008 ', 'shamma181@gmail.com', '01600000006', 'EEE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63233a9122f5c3.31883244.jpg', '3.33', '', '', '', '', '', ''),
('Md. Imran Hossain', '1996-06-30T17:45', 'Male', '021181012 ', 'imran181@gmail.com', '01600000007', 'EEE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63233aef838c54.76596866.png', '3.90', '', '', '', '', '', ''),
('Md. Ridoy Ad. Sumon', '1996-09-12T11:40', 'Male', '021181051', 'ridoy181@gmail.com', '01600000008', 'EEE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63233b4d008716.84346291.jpg', '3.17', '', '', '', '', '', ''),
('Redwan Ahmmed', '1997-02-19T05:50', 'Male', '021181066', 'redwan181@gmail.com', '01600000009', 'EEE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63233ba6e016b5.98988339.jpg', '3.50', '', '', '', '', '', ''),
('Masum Rana', '1998-08-25T16:40', 'Male', '021212004 ', 'rana212@gmail.com', '01600000010', 'EEE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63233c07a6c5b3.21562873.jpg', '3.54', '', '', '', '', '', ''),
('Al Mahmud Hossain', '1998-08-18T07:40', 'Male', '021212010', 'mahmud212@gmail.com', '01600000011', 'EEE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63233c7a39d4b6.49275948.jpg', '3.25', '', '', '', '', '', ''),
('Nissan Biswas', '2002-03-12T21:53', 'Male', '021213001', 'nbiswas213001@bseee.uiu.ac.bd', '01703185440', 'EEE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63234b27665de7.68412936.jpg', '4.00', '', '', '', '', '', ''),
('Fatema Nasrin Daana', '1999-05-22T06:50', 'Female', '021221003', 'fatema221@gmail.com', '01600000012', 'EEE', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63233cb7be4ef8.19346312.jpg', '3.64', '', '', '', '', '', ''),
('Md Musfiqur Rashid', '1999-06-14T10:40', 'Male', '021221011', 'rashid221@gmail.com', '01600000013', 'EEE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Amena Akter Mishu', '1996-06-30T20:40', 'Female', '111172002 ', 'mishu172@gmail.com', '01900000000', 'BBA', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63233d5b732ca9.87526112.jpg', '3.25', '', '', '', '', '', ''),
('Jenia Alam Juhe', '1996-09-26T16:40', 'Female', '111172055', 'juhi172@gmail.com', '01900000001', 'BBA', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63233e04394211.98694698.jpg', '3.80', '', '', '', '', '', ''),
('Sabrina Abrar', '1997-06-28T18:50', 'Female', '111181002', 'abrar181@gmail.com', '01900000003', 'BBA', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63233e4cb01252.07418160.jpg', '3.25', '', '', '', '', '', ''),
('Md Rasel Mia', '1998-06-22T11:50', 'Male', '111182027', 'rasel182@gmail.com', '01900000004', 'BBA', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63233e94d50f92.45214331.jpg', '3.15', '', '', '', '', '', ''),
('Sumaiya Murshid ', '1998-03-09T04:50', 'Female', '111221068 ', 'murshid221@gmail.com', '01900000005', 'BBA', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63233ed51b9f30.03180725.jpg', '3.65', '', '', '', '', '', ''),
('Md. Al Emran Talukdar', '1998-03-07T19:40', 'Male', '111221092', 'emran221@gmail.com', '01900000006', 'BBA', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63233f174b5a46.69982195.jpg', '3.56', '', '', '', '', '', ''),
('Tahmid Hossain', '1998-08-27T09:50', 'Male', '111221167', 'tahmid221@gmail.com', '01900000007', 'BBA', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63233f49f19059.89405705.jpg', '3.25', '', '', '', '', '', ''),
('Abdullah Al Sakib', '2022-11-12T21:05', 'Male', '111223344', 'sakibdob@gmail.com', '01775332747', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('Rayhan Ahmed Abir', '1999-09-12T19:40', 'Male', '114221001 ', 'abir221@gmail.com', '01900000008', 'BBA', '81dc9bdb52d04dc20036dbd8313ed055', 'IMG-63233f862000b8.16866980.jpg', '3.80', '', '', '', '', '', ''),
('mokka', '2022-10-26T01:10', 'Male', '1234', 'abdullahalsakib7075@gmail.com', '01775332747', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', ''),
('rhwer', '2022-11-12T21:07', 'Male', 'Sakib', 'sakibdob@gmail.com', '01775332747', 'CSE', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ta`
--

CREATE TABLE `ta` (
  `id` int(11) NOT NULL,
  `sname` varchar(250) NOT NULL,
  `sid` varchar(250) NOT NULL,
  `cname` varchar(250) NOT NULL,
  `cid` varchar(250) NOT NULL,
  `section` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ta`
--

INSERT INTO `ta` (`id`, `sname`, `sid`, `cname`, `cid`, `section`) VALUES
(20, 'Saif ', '011201223', 'Structured Programming Language', ' CSE 1111', 'A'),
(21, 'Emon Karmoker', '011201386', 'Structured Programming Language', ' CSE 1111', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `id` varchar(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `room` varchar(200) NOT NULL,
  `department` varchar(200) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `number` varchar(29) NOT NULL,
  `dob` varchar(200) NOT NULL,
  `profession` varchar(255) NOT NULL,
  `pid` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`id`, `name`, `email`, `password`, `room`, `department`, `gender`, `number`, `dob`, `profession`, `pid`, `image`) VALUES
('A.K.M', 'Dr. A.K.M. Muzahidul Islam', 'akm@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '01789644322', '1980-09-18T15:47', 'Associate Professor', 4, ''),
('AA', 'Ajwad Akil', 'akil@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '01879633445', '1995-02-14T14:59', 'Lecturer', 6, ''),
('ABS', 'Prof. Dr. Md. Abu Saklayen', 'saklayen@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0165887942', '1974-11-15T16:00', 'Professor', 3, ''),
('AH', 'Mr. Md. Abir Hassan', 'ahassan@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '636', 'CSE', 'Male', '0170000010', '1991-07-27T18:24', 'Lecturer', 6, 'IMG-63233d91e10c74.11541752.jpg'),
('AKM', 'Dr. Md. Abul Kashem Mia', 'kashem@uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0170000002', '1985-07-27T16:08', 'Professor & Pro-Vice Chancellor', 2, ''),
('AM', 'Mr. Anik Mazumder', 'mazumder@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '418(B)', 'CSE', 'Male', '0170000014', '1996-07-27T21:03', 'Lecturer', 6, 'IMG-6326dae26cb105.99136773.jpg'),
('ARO', 'Mr. Abu Zafar Md. Rashed Osman', 'osman@bba.cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'BBA', 'Male', '01623398874', '1988-09-15T19:27', 'Lecturer', 6, ''),
('AS', 'Adiba Shaira', 'adiba@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Female', '0156977565', '1992-10-15T14:28', 'Lecturer', 6, ''),
('ASSZ', 'Prof. Dr. Abu Saleh Md. Sohel-Uz-Zaman', 'saleh@bba.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'BBA', 'Male', '01654478231', '1981-09-21T18:59', 'Professor', 3, ''),
('ATR', ' Anika Tasnim Rodela', 'anika@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '636', 'CSE', 'Female', '0170000030', '1995-06-07T07:31', 'Lecturer', 6, 'IMG-63233747341e81.46322918.jpg'),
('AVS', 'Mr. Avijit Saha', 'avijit@eee.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'EEE', 'Male', '0178956565', '1981-07-27T23:55', '	Assistant Professor', 5, ''),
('AZ', 'Mr. Akib Zaman', 'akib@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '319(b)', 'CSE', 'Male', '0170000021', '1993-07-27T14:29', 'Lecturer', 6, 'IMG-632332fe9cf037.76256798.jpg'),
('BA', 'Mr. Md. Benzir Ahamed', 'benzir@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0170000009', '1990-07-27T17:20', '	Assistant Professor', 5, ''),
('BJ', 'Mr. Mohammad Behroz Jalil', 'behroz@bba.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'BBA', 'Male', '0189741236', '1986-11-15T18:51', 'Lecturer', 6, ''),
('BKM', 'Mr. B.K.M. Mizanur Rahman', 'bkm@gamil.com', '81dc9bdb52d04dc20036dbd8313ed055', '', 'EEE', 'Male', '0159764856', '1981-09-14T18:27', '	Assistant Professor', 5, ''),
('CMR', 'Dr. Chowdhury Mofizur Rahman', 'cmr@uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0170000001', '1985-07-27T15:05', 'Professor&Vice Chancellor', 1, 'IMG-6326ddd3af9b94.00750651.jpg'),
('DF', 'Dr. Dewan Md. Farid', 'dewanfarid@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '533(B)', 'CSE', 'Male', '0170000023', '1987-07-28T21:21', 'Professor', 3, 'IMG-63233f140f58f2.25139488.png'),
('FAH', 'Mr. Farhan Anan Himu', 'himu@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '536(A)', 'CSE', 'Male', '0170000016', '1996-07-15T23:13', 'Lecturer', 6, 'IMG-632335be168b87.66274070.jpg'),
('FF', 'Ms. Farhanaz Farheen', 'farheen@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Female', '01700000012', '1994-07-27T21:01', 'Lecturer', 6, ''),
('FH', 'Fahim Hafiz', 'fahimhafiz@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '636', 'CSE', 'Male', '015642697', '1990-02-06T14:24', 'Lecturer', 6, 'IMG-632341a72deba4.98626849.jpg'),
('FTI', 'Fariha Tabassum Islam', 'fariha@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '336', 'CSE', 'Female', '0170000013', '1992-07-27T18:25', 'Lecturer', 6, 'IMG-63233687eb2333.86437016.jpg'),
('gh', 'gh', 'sakibdob@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '01775332747', '2022-10-26T13:12', 'Professor & Vice Chancellor', 0, ''),
('GKR', 'Gourab Kumar Roy', 'gourabkumar@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '01897565566', '1987-05-15T14:55', 'Lecturer', 6, ''),
('GR', 'Gourab Kumar Roy', 'gourab@eee.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0170410014', '1990-02-21T18:02', 'Lecturer', 6, ''),
('GS', 'Gourab Saha', 'gourab@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '01536698874', '1989-03-24T20:52', 'Lecturer', 6, ''),
('HAA', 'Hasin Anupama Azhari', 'azhari@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0178965425', '1988-11-17T14:51', 'Lecturer', 6, ''),
('HAK', 'Md. Hasan Al Kayem', 'hasan@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0189654726', '1987-10-27T15:40', 'Lecturer', 6, ''),
('HB', 'Ms. Helena Bulbul', 'helena@eee.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'EEE', 'Female', '0171655965', '1987-07-27T13:14', 'Lecturer', 6, ''),
('HS', 'Dr. Hasan Sarwar', 'hsarwar@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0170000003', '1990-07-27T17:10', 'Professor', 3, ''),
('IA', 'Dr. Intekhab Alam', 'intekhab@eee.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'EEE', 'Male', '07954566856', '1980-06-29T22:58', 'Professor', 3, ''),
('IBC', 'Dr. Md. Iqbal Bahar Chowdhury', 'ibchy@eee.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'EEE', 'Male', '017956565955', '1985-07-27T20:47', 'Associate Professor', 4, ''),
('IS', 'Ms. Ishrat Sultana', 'israt@bba.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'BBA', 'Female', '0178993540', '1991-01-15T19:31', 'Lecturer', 6, ''),
('JHC', 'Jerin Haque Chhanda', 'chhanda@bba.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'EEE', 'Female', '01623398874', '1995-01-24T19:06', 'Lecturer', 6, ''),
('JS', 'Jashodhan Saha', 'Jashodhan@cse.uiu.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '01789654112', '1980-10-20T15:27', 'Lecturer', 6, ''),
('KH', 'Md. Kazimul Hoque', 'kazimul@bba.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'BBA', 'Male', '01623398845', '1989-09-20T18:40', 'Lecturer', 6, ''),
('KIUA', 'Dr. Khawza Iftekhar Uddin Ahmed', 'khawza@eee.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'EEE', 'Male', '0187412356', '1981-06-15T18:16', 'Professor', 6, ''),
('KMR', 'Dr. Kaled Masukur Rahman', 'masuk@eee.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'EEE', 'Male', '0175945495', '1991-05-30T19:46', 'Professor', 3, ''),
('KSM', 'Mr. Kazi Sajeed Mehrab', 'sajeed@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0170000021', '1995-07-27T22:02', 'Lecturer', 6, ''),
('MAA', 'Dr. Mohammad A. Ashraf', 'mmashraf@bus.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'BBA', 'Male', '018756565656', '1975-02-23T20:32', 'Professor', 3, ''),
('MAS', 'Moynuddin Ahmed Shibly', 'shibly@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0178546324', '1988-12-16T15:34', 'Lecturer', 6, ''),
('MASQ', 'Mr. Mohammad Mahboob Ali Siddiqi', 'mahbub@eee.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0178932154', '1987-08-19T17:31', 'Lecturer', 6, ''),
('MB', 'Minhajul Bashir', 'bashir@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '01896635578', '1990-01-24T20:28', 'Lecturer', 6, ''),
('MHM', 'Mr. Mofijul Hoq Masum', 'masum@bba.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'BBA', 'Male', '01864762356', '1990-01-15T18:44', 'Lecturer', 6, ''),
('MHR', 'Mr. Md. Mahbub Hossain Raton', 'mahbub@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '636', 'CSE', 'Male', '0170000017', '1993-07-14T19:09', 'Lecturer', 6, 'IMG-63233fbd1010e9.37028794.jpg'),
('MHU', 'Mr. Md. Mumtahin Habib Ullah Mazumder', 'mumtahin@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0170000019', '1995-07-15T11:14', 'Lecturer', 6, ''),
('MNH', 'Dr.Mohammad Nurul Huda', 'mnh@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0170000004', '1985-06-29T14:18', 'Professor', 3, ''),
('MOR', 'Dr. Mir Obaidur Rahman', 'obaidur@eco.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'BBA', 'Male', '01876256563', '1982-07-27T13:32', 'Professor', 3, ''),
('MQ', 'Md. Qamruzzaman', 'qamruzzaman@bba.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'BBA', 'Male', '01302364589', '1984-08-22T19:04', 'Lecturer', 6, ''),
('MR', 'Md. Mizanur Rahman', 'mizan@eee.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'EEE', 'Male', '0198742365', '1988-12-23T17:54', 'Lecturer', 6, ''),
('MS', 'Ms. Mimnun Sultana', 'mimnun@bba.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'BBA', 'Female', '01788987452', '1988-03-23T18:37', 'Lecturer', 6, ''),
('MSS', 'Ms. Musharrat Shabnam Shuchi', 'shabnam@eco.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'BBA', 'Female', '017956565662', '1982-06-16T23:36', 'Lecturer', 6, ''),
('NC', 'Mr. Md. Nadeem Chowdhury', 'nadeem@eee.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '538', 'EEE', 'Female', '0178995656', '1991-07-06T20:18', 'Lecturer', 6, ''),
('NH', 'Nahid Hossain', 'nahid@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '01654487796', '1984-12-31T15:04', 'Lecturer', 6, ''),
('NR', 'Ms.Nipa Roy', 'nipa@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Female', '0178966555', '1989-09-18T14:36', 'Lecturer', 6, ''),
('NSS', 'Ms. Nabila Sabrin Sworna', 'nabila@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Female', '0170000018', '1996-07-27T23:12', 'Lecturer', 6, ''),
('QFN', 'Ms. Quazi Farah Nawar', 'arah@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Female', '0170004021', '1991-07-08T22:28', 'Lecturer', 6, ''),
('RA', 'Md. Rayhan Ahmed', 'rayhan@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '418(A)', 'CSE', 'Male', '01716857548', '1991-06-04T20:09', 'Lecturer', 6, 'IMG-63233b701ef672.89608493.jpeg'),
('RK', 'Dr. M. Rezwan Khan', 'rezwanm@uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'EEE', 'Male', '0175865655', '1987-06-01T21:41', 'Professor', 3, ''),
('RM', 'Dr. Raqibul Mostafa', 'rmostafa@eee.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'EEE', 'Male', '01755559989', '1981-07-14T12:42', 'Professor', 3, ''),
('RRK', 'Ms. Rubaiya Rahtin Khan', 'rubaiya@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Female', '0170000027', '1996-07-14T21:23', '	Assistant Professor', 5, ''),
('RUR', 'Md. Rafi-Ur-Rashid', 'rafiurrashid@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0170000789', '1998-05-18T12:36', 'Lecturer', 6, ''),
('SAH', 'Sufi Aurangzeb Hossain', 'Aurangzeb@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0198745265', '1983-11-16T15:21', 'Lecturer', 6, ''),
('SAI', 'Sadia Islam', 'sadia@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '319', 'CSE', 'Female', '0170000015', '1995-06-16T22:07', 'Lecturer', 6, 'IMG-63581c6b917772.58531229.jpg'),
('sakib1122', 'Abdullah Al Sakib', 'sakibdob@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0111', '2022-11-12T21:08', 'Lecturer', 0, 'IMG-637347ddbf6af6.05369191.jpg'),
('SAMD', 'Mr. Salahuddin Ahmed', 'salahuddin@eee.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'EEE', 'Male', '0198745620', '1986-12-17T17:34', 'Lecturer', 6, ''),
('SAS', 'Mr. Shoib Ahmed Shourav', 'shoib@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '536', 'CSE', 'Male', '0170000011', '1992-07-27T08:23', 'Lecturer', 6, 'IMG-6323351a896984.78444761.jpg'),
('SeyS', 'Dr. Seyama Sultana', 'seyama@bba.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'BBA', 'Female', '0189562152', '1989-05-15T19:16', 'Professor', 3, ''),
('SHA', 'Mr. Md. Saidul Hoque Anik', 'anik@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0170000024', '1990-06-30T22:22', 'Lecturer', 6, ''),
('SHM', 'Dr. Md. Saddam Hossain Mukta', 'saddam@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0170000007', '1989-07-27T18:17', 'Associate Professor', 4, ''),
('SHS', 'Shoumik Saha', 'shoumik@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0170000024', '1995-07-14T21:22', 'Lecturer', 6, ''),
('SI', 'Dr. Salekul Islam', 'salekul@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0170000005', '1988-07-12T16:13', 'Professor', 3, ''),
('SKP', 'Dr. Al-Sakib Khan Pathan', 'sakib@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '01700000026', '1998-07-01T17:05', 'Professor', 3, 'IMG-6326dd54417289.51717597.jpg'),
('SKS', 'Mr. Subangkar Karmaker Shanto', 'shanto@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0170000020', '1996-07-29T12:14', 'Lecturer', 6, ''),
('SM', 'Mr. Suman Ahmmed', 'suman@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0170000008', '1988-07-27T17:22', '	Assistant Professor', 5, ''),
('SnM', 'Sandid Muneer', 'sadidmuneer@eee.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'EEE', 'Male', '01795654596', '1985-07-27T22:53', '	Assistant Professor', 5, ''),
('SS', 'Dr. Swakkhar Shatabda', 'swakkhar@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'CSE', 'Male', '0170000006', '1988-07-15T14:19', 'Professor', 3, ''),
('TA', 'Ms. Tanzila Amir', 'tanzila@eco.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'BBA', 'Female', '0186556551', '1991-02-18T23:38', 'Lecturer', 6, ''),
('TH', 'MD. TAREK HASAN', 'tarek@cse.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '319(c)', 'CSE', 'Male', '0170000029', '1996-07-08T22:26', 'Lecturer', 6, 'IMG-63233a9d7faac5.74536926.jpg'),
('WY', 'Dr. Wahida Yasmeen', 'wahida@eco.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'BBA', 'Female', '0187956865', '1981-07-30T12:34', 'Associate Professor', 4, ''),
('ZA', 'Mr. Md. Zubair Alam', 'zubair@eee.uiu.ac.bd', '81dc9bdb52d04dc20036dbd8313ed055', '', 'EEE', 'Male', '0171895564', '1993-06-30T22:16', 'Lecturer', 6, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `apply`
--
ALTER TABLE `apply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD UNIQUE KEY `id` (`id`,`email`);

--
-- Indexes for table `ta`
--
ALTER TABLE `ta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `apply`
--
ALTER TABLE `apply`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `ta`
--
ALTER TABLE `ta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
